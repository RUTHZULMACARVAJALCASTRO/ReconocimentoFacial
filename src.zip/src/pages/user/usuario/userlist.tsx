// ** Next Imports
import Router, { useRouter } from 'next/router';

// ** MUI Imports
import Image from 'next/image'

// ** MUI Imports
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import Menu from '@mui/material/Menu'
import Grid from '@mui/material/Grid'

import { DataGrid } from '@mui/x-data-grid'
import { styled } from '@mui/material/styles'
import MenuItem from '@mui/material/MenuItem'
import IconButton from '@mui/material/IconButton'
import Typography from '@mui/material/Typography'
import Icon from 'src/@core/components/icon';
import { useState, useEffect, MouseEvent, useCallback } from 'react'
import Link from 'next/link'
import user, { fetchUsers } from 'src/store/apps/user/index';
import { useDispatch, useSelector } from 'react-redux'
import { RootState } from 'src/store';
import { AppDispatch } from 'src/redux/store';
import CustomChip from 'src/@core/components/mui/chip'
import CustomAvatar from 'src/@core/components/mui/avatar'
import { getInitials } from 'src/@core/utils/get-initials'
import { ThemeColor } from 'src/@core/layouts/types'

import TableHeader from 'src/views/apps/user/list/TableHeaderUser'
import AddUserDrawer from 'src/views/apps/user/list/AddUserDrawer'
import SidebarEditUser from 'src/views/apps/user/list/EditUserDrawer'
import { rows } from 'src/@fake-db/table/static-data';
import axios from 'axios';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Button from '@mui/material/Button';

// Interfaces
interface Docu {
  _id: string;
  name: string;
  lastName: string;
  ci: string;
  email: string;
  phone: string;
  address: string;
  nationality: string;
  unity: string;
  charge: string;
  schedule: string;
  file: string;
  isActive: boolean;
  avatarColor?: ThemeColor;
}

interface CellType {
  row: Docu
}

interface UserStatusType {
  [key: string]: ThemeColor
}

// Componente Principal
const UserList = () => {
  // ** State
  // const [data, setData] = useState<Docu[]>([])
  const [value, setValue] = useState<string>('')
  const [pageSize, setPageSize] = useState<number>(10)
  const [addUserOpen, setAddUserOpen] = useState<boolean>(false)
  const [editUserOpen, setEditUserOpen] = useState<boolean>(false)
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);


  // const dispatch = useDispatch();
  const dispatch = useDispatch<AppDispatch>()
  const users: Docu[] = useSelector((state: RootState) => state.users.list);

  const toggleUserActivation = async (userId: string, isActive: boolean) => {
    console.log(`Setting user with ID ${userId} active status to: ${isActive}`);

    try {
      const response = await axios.put(`${process.env.NEXT_PUBLIC_PERSONAL}edit/${userId}`, { isActive: isActive });

      if (response.status === 200) {
        console.log("User status updated successfully!");
      } else {
        console.error("Error updating user status:", response.data);
      }

    } catch (error) {
      console.error("Error making the PUT request to update status:", error);
    }
  };

  useEffect(() => {
    dispatch(fetchUsers());
  }, [dispatch]);

  const userStatusObj: UserStatusType = {
    activo: 'success',
    inactivo: 'secondary'
  }

  const StyledLink = styled(Link)(({ theme }) => ({
    fontWeight: 600,
    fontSize: '1rem',
    cursor: 'pointer',
    textDecoration: 'none',
    color: theme.palette.text.secondary,
    '&:hover': {
      color: theme.palette.primary.main
    }
  }))

  const convertBase64ToImageUrl = (base64String: string) => {
    return `data:image/png;base64,${base64String}`
  }

  const renderClient = (row: Docu) => {
    let imageSrc = convertBase64ToImageUrl(row.file);
    console.log(imageSrc)
    if (row.file) {
      // return <img src={imageSrc} style={{ width: '34px', height: '34px' }} />;
      return <CustomAvatar src={imageSrc} sx={{ mr: 3, width: 34, height: 34 }} />;
    } else {
      return (
        <CustomAvatar
          skin='light'
          color={row.avatarColor || 'primary'}
          sx={{ mr: 3, width: 34, height: 34, fontSize: '1rem' }}
        >
          {getInitials(row.name ? row.name : '')}
        </CustomAvatar>
      )
    }
  }

  const RowOptions = ({ id, isActive }: { id: number | string, isActive: boolean }) => {

    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
    const [openDialog, setOpenDialog] = useState(false);
    const rowOptionsOpen = Boolean(anchorEl)


    const handleOpenDialog = () => {
      setOpenDialog(true);
    };

    const handleCloseDialog = () => {
      setOpenDialog(false);
    };

    const handleDeactivate = () => {
      toggleUserActivation(id.toString(), false);
      setOpenDialog(false);
    };

    const handleReactivate = () => {
      toggleUserActivation(id.toString(), true);
    };

    const handleRowOptionsClick = (event: MouseEvent<HTMLElement>) => {
      setAnchorEl(event.currentTarget)
    }
    const handleRowOptionsClose = () => {
      setAnchorEl(null)
    }


    const handleUpdate = (userId: string) => () => {
      setSelectedUserId(userId);
      setEditUserOpen(true);
    };

    return (
      <>
        <IconButton size='small' onClick={handleRowOptionsClick}>
          <Icon icon='mdi:dots-vertical' />
        </IconButton>
        <Menu
          keepMounted
          anchorEl={anchorEl}
          open={rowOptionsOpen}
          onClose={handleRowOptionsClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'right'
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right'
          }}
          PaperProps={{ style: { minWidth: '8rem' } }}
        >

          <MenuItem onClick={handleUpdate(id.toString())} sx={{ '& svg': { mr: 2 } }}>
            <Icon icon='mdi:edit' fontSize={20} />
            Editar
          </MenuItem>
          <MenuItem onClick={isActive ? handleOpenDialog : handleReactivate} sx={{ '& svg': { mr: 2 } }}>
            <Icon icon={isActive ? 'mdi:delete-outline' : 'mdi:account-check-outline'} fontSize={20} />
            {isActive ? 'Dar de Baja' : 'Reactivar'}
          </MenuItem>
        </Menu>

        <Dialog open={openDialog} onClose={handleCloseDialog}>
          <DialogTitle>¿Estás seguro?</DialogTitle>
          <DialogContent>
            <DialogContentText>¿Realmente quieres desactivar este usuario?</DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog} color="primary">
              Cancelar
            </Button>
            <Button onClick={handleDeactivate} color="primary">
              Desactivar
            </Button>
          </DialogActions>
        </Dialog>
      </>
    )
  }

  const handleFilter = useCallback((val: string) => {
    setValue(val)
  }, [])

  const toggleAddUserDrawer = () => setAddUserOpen(!addUserOpen)
  const toggleEditUserDrawer = () => setEditUserOpen(!editUserOpen)
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const columns = [
    {
      flex: 0.2,
      minWidth: 230,
      field: 'fullName',
      headerName: 'Usuario',
      renderCell: ({ row }: CellType) => {
        const { name, lastName } = row

        return (
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            {renderClient(row)}
            <Box sx={{ display: 'flex', alignItems: 'flex-start', flexDirection: 'column' }}>
              <StyledLink href={`/user/usuario/view/${row._id}/`}>{[name, ' ', lastName]}</StyledLink>
            </Box>
          </Box>
        )
      },
    },
    {
      flex: 0.1,
      minWidth: 150,
      field: 'ci',
      headerName: 'CI',
      renderCell: ({ row }: CellType) => {
        return (
          <Typography noWrap variant='body2'>
            {row.ci}
          </Typography>
        )
      }
    },
    {
      flex: 0.1,
      minWidth: 110,
      field: 'email',
      headerName: 'Email',
      renderCell: ({ row }: CellType) => {
        return (
          <Typography noWrap variant='body2'>
            {row.email}
          </Typography>
        )
      }
    },
    {
      flex: 0.1,
      minWidth: 110,
      field: 'phone',
      headerName: 'Celular',
      renderCell: ({ row }: CellType) => {
        return (
          <Typography noWrap variant='body2'>
            {row.phone}
          </Typography>
        )
      }
    },
    {
      flex: 0.1,
      minWidth: 110,
      field: 'address',
      headerName: 'Direccion',
      renderCell: ({ row }: CellType) => {
        return (
          <Typography noWrap variant='body2'>
            {row.address}
          </Typography>
        )
      }
    },
    {
      flex: 0.1,
      minWidth: 110,
      field: 'nationality',
      headerName: 'Nacionalidad',
      renderCell: ({ row }: CellType) => {
        return (
          <Typography title={row.nationality} noWrap variant='body2'>
            {row.nationality}
          </Typography>
        )
      }
    },

    {
      flex: 0.1,
      minWidth: 110,
      field: 'status',
      headerName: 'Estado',
      renderCell: ({ row }: CellType) => {
        const status = row.isActive ? 'activo' : 'inactivo';
        return (
          <CustomChip
            skin='light'
            size='small'
            label={status}
            color={userStatusObj[status]}
            sx={{ textTransform: 'capitalize', '& .MuiChip-label': { lineHeight: '18px' } }}
          />
        )
      }
    },
    {
      flex: 0.1,
      minWidth: 90,
      sortable: false,
      field: 'actions',
      headerName: 'Acciones',
      renderCell: ({ row }: CellType) => <RowOptions id={row._id} isActive={row.isActive} />
    }
  ]

  return (
    <>
      <Grid container spacing={6}>
        <Grid item xs={12}>
          <Card>
            <TableHeader value={value} handleFilter={handleFilter} toggle={toggleAddUserDrawer} />
            <DataGrid
              rowHeight={60}
              getRowId={row => row._id}
              autoHeight
              rows={users}
              columns={columns}
              pageSize={pageSize}
              disableSelectionOnClick
              sx={{
                '& .MuiDataGrid-columnHeaders': { borderRadius: 0 }, '& .MuiDataGrid-window': {
                  overflow: 'hidden'
                }
              }}
              onPageSizeChange={(newPageSize: number) => setPageSize(newPageSize)}
              localeText={{
                filterOperatorAfter: 'después de',
                filterOperatorOnOrAfter: 'en o después de',
                filterOperatorBefore: 'antes de',
                filterOperatorOnOrBefore: 'en o antes de',
                filterOperatorEquals: 'igual a',
                filterOperatorStartsWith: 'comienza con',
                filterOperatorEndsWith: 'termina con',
                filterOperatorContains: 'contiene',
                columnMenuLabel: 'Menú de columna',
                columnMenuShowColumns: 'Mostrar columnas',
                columnMenuFilter: 'Filtrar',
                columnMenuHideColumn: 'Ocultar',
                columnMenuUnsort: 'Desordenar',
                columnMenuSortAsc: 'Ordenar Asc',
                columnMenuSortDesc: 'Ordenar Desc',
                toolbarDensity: 'Densidad',
                toolbarDensityLabel: 'Densidad',
                toolbarDensityCompact: 'Compacto',
                toolbarDensityStandard: 'Estándar',
                toolbarDensityComfortable: 'Cómodo',
                noRowsLabel: 'No hay filas',
                noResultsOverlayLabel: 'No se encontraron resultados.',
                errorOverlayDefaultLabel: 'Ocurrió un error.'
              }}

            />
          </Card>
        </Grid>
        <AddUserDrawer open={addUserOpen} toggle={toggleAddUserDrawer} />
        {selectedUserId && <SidebarEditUser userId={selectedUserId} open={editUserOpen} toggle={() => setEditUserOpen(false)} />}
      </Grid>
    </>
  )
}

export default UserList