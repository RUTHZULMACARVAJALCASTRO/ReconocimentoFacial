import React, { useEffect, useState } from 'react';
import {
  Collapse,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  TableCell,
  TableRow,
  Button,
  TableHead,
  Paper,
  Table,
  TableBody,
  TableContainer,
  useTheme,
  Typography,
} from '@mui/material';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import axios from 'axios';
import { makeStyles } from '@mui/styles';
import SidebarAddHorario from '../../../views/apps/schedule/AddHorario';
import SidebarEditHorario from '../../../views/apps/schedule/EditHorario';


interface Schedule {
  day: number;
  name: string;
  into: string;
  out: string;
  intoTwo: string;
  outTwo: string;
  toleranceInto: number;
  toleranceOut: number;

  permanente: boolean;
  dateRange: string[];
  usersAssigned: string[];
}


interface Docu {
  _id: string;
  name: string;
  scheduleNormal: Schedule[];
  scheduleSpecial: Schedule[];
  isActive: boolean;
}

interface RowProps {
  row: Docu;
}

const useStyles = makeStyles((theme: any) => ({
  tableRowLight: {
    backgroundColor: theme.palette.background.paper,
  },
  tableRowDark: {
    backgroundColor: theme.palette.background.default,
  },
  tableCell: {
    textAlign: 'center',
  },
}));

const dias = ['DOMINGO', 'LUNES', 'MARTES', 'MIÉRCOLES', 'JUEVES', 'VIERNES', 'SÁBADO'];

function Row(props: RowProps) {
  const { row } = props;
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const theme = useTheme();
  const [editHorarioOpen, setEditHorarioOpen] = useState<boolean>(false);
  const toggleEditHorario = () => {
    // Lógica para abrir o cerrar la edición del horario
    setEditHorarioOpen(!editHorarioOpen);
    const handleToggleActive = async (scheduleId: string, newStatus: boolean) => {
      try {
        // Resto del código...
      } catch (error) {
        console.error('Error al cambiar el estado del horario:', error);
      }
    };
  };

  const handleToggleActive = async (scheduleId: string, newStatus: boolean) => {
    try {
      const response = await axios.put(`${process.env.NEXT_PUBLIC_PERSONAL_SCHEDULE}/${scheduleId}/active`, {
        isActive: newStatus,
      });

      if (response.status === 200 || response.status === 201) {

        console.log(`Horario ${newStatus ? 'activado' : 'dado de baja'} con éxito:`, response.data);
      } else {
        console.error('Respuesta inesperada del servidor:', response);
      }
    } catch (error) {
      console.error('Error al cambiar el estado del horario:', error);
    }
  };

  return (
    <React.Fragment>
      <TableRow
        className={row.isActive ? classes.tableRowLight : classes.tableRowDark}
        sx={{ '& > *': { borderBottom: 'unset', border: '1px solid #e0e0e0' } }}
      >
        <TableCell align='center'>
          <IconButton aria-label="expand row" size="small" onClick={() => setOpen(!open)}>
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell align='center'>{row.name}</TableCell>
        <TableCell colSpan={7}>
          <Typography align='center'>{open ? '' : '...'}</Typography>

          <Collapse in={open} timeout="auto" unmountOnExit>
            {open ? (
              <Table>
                <TableHead>
                  <TableRow sx={{
                    '&:nth-of-type(odd)': {
                      backgroundColor: open ? theme.palette.mode === 'dark' ? '#263238' : '#263238' : theme.palette.mode === 'dark' ? '#263238' : '#263238',
                      boxShadow: 'inset 0px 0px 5px rgba(0, 0, 0, 0.5)',
                      color: '#ffffff',
                    },
                    '& > *': {
                      borderBottom: '1px solid #ccc',
                      color: '#ffffff',
                    }
                  }}>
                    <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 10px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                      DÍA
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 50px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                      MAÑANA ENTRADA
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 50px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                      MAÑANA SALIDA
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 50px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                      TARDE ENTRADA
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 50px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                      TARDE SALIDA
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 24px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                      TOLERANCIA ENTRADA
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 24px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                      TOLERANCIA SALIDA
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 24px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                      ...
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody sx={{ '& > *': { borderBottom: '1px solid #ccc', borderLeft: '1px solid #ccc', borderRight: '1px solid #ccc' } }}>
                  {row.scheduleNormal && row.scheduleNormal.map((schedule, index) => (
                    <TableRow
                      key={index}
                      sx={{
                        '&:nth-of-type(odd)': {
                          backgroundColor: theme.palette.mode === 'dark' ? '#9e9e9e ' : '#F4F4F4',
                          color: theme.palette.mode === 'dark' ? '#000000' : '#000000',
                        },
                        '& > *': {
                          borderBottom: '1px solid #ccc',
                        },
                      }}
                    >
                      <TableCell align="center">{dias[schedule.day]}</TableCell>
                      <TableCell align="center">{schedule.into || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.out || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.intoTwo || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.outTwo || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.toleranceInto || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.toleranceOut || 'N/A'}</TableCell>
                      <TableCell align="center">{ }</TableCell>
                    </TableRow>
                  ))}

                  {row.scheduleSpecial && row.scheduleSpecial.length > 0 && (
                    <TableRow
                      sx={{
                        '&:nth-of-type(odd)': {
                          backgroundColor: theme.palette.mode === 'dark' ? '#9e9e9e' : '#F4F4F4',
                          color: '#000000',
                        },
                        '& > *': {
                          borderBottom: '1px solid #ccc',
                        }
                      }}
                    >
                      <TableCell
                        colSpan={8} // El número de columnas debe coincidir con la cantidad de datos en tu horario especial
                        className={classes.tableCell}
                        align="center"
                        sx={{
                          '&:nth-of-type(odd)': {
                            backgroundColor: open ? theme.palette.mode === 'dark' ? '#263238' : '#263238' : theme.palette.mode === 'dark' ? '#263238' : '#263238',
                            boxShadow: 'inset 0px 0px 5px rgba(0, 0, 0, 0.5)',
                            color: '#ffffff',
                          },
                          '& > *': {
                            borderBottom: '1px solid #ccc',
                            color: '#ffffff',
                          }
                        }}
                      >
                        HORARIO ESPECIAL
                      </TableCell>
                    </TableRow>
                  )}

                  {row.scheduleSpecial && row.scheduleSpecial.map((schedule, index) => (
                    <TableRow
                      key={`${row._id}-special-${index}`}
                      sx={{
                        '&:nth-of-type(odd)': {
                          backgroundColor: theme.palette.mode === 'dark' ? '#9e9e9e' : '#F4F4F4',
                          color: '#000000',
                        },
                        '& > *': {
                          borderBottom: '1px solid #ccc',
                        }
                      }}
                    >
                      <TableCell align="center">{dias[schedule.day]} {schedule.name} </TableCell>
                      <TableCell align="center">{schedule.into || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.out || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.intoTwo || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.outTwo || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.toleranceInto || 'N/A'}</TableCell>
                      <TableCell align="center">{schedule.toleranceOut || 'N/A'}</TableCell>
                      {/* <TableCell align="center">{schedule.permanente || 'N/A'}</TableCell> */}
                      <TableCell align="center">
                        {schedule.dateRange && schedule.dateRange.map((date, dateIndex) => (
                          <div key={dateIndex}>{new Date(date).toLocaleDateString()}</div>
                        ))}
                      </TableCell>
                      {/* <TableCell align="center">{schedule.usersAssigned || 'N/A'}</TableCell> */}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <React.Fragment>
                <Typography variant="body1" style={{ padding: '16px' }}>
                  Haga clic en la flecha para ver el horario.
                </Typography>
              </React.Fragment>
            )}

            <>
              <br />
              <SidebarEditHorario open={editHorarioOpen} toggle={toggleEditHorario} scheduleId={''} />
              {/* <Button
                variant="contained"
                color={row.isActive ? 'secondary' : 'primary'}
                onClick={() => handleToggleActive(row._id, !row.isActive)}
                style={{ marginLeft: '8px' }} // Agrega un margen izquierdo para crear espacio
              >
                {row.isActive ? 'Dar de baja' : 'Activar'}
              </Button> */}
            </>
          </Collapse>

        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}

export default function CollapsibleTable() {
  const [data, setData] = useState<Docu[]>([]);
  const [addHorarioOpen, setAddHorarioOpen] = useState<boolean>(false);
  const toggleAddHorario = () => setAddHorarioOpen(!addHorarioOpen);
  const classes = useStyles();
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const [editHorarioOpen, setEditHorarioOpen] = useState<boolean>(false);

  const toggleEditHorario = (scheduleId: string | null) => {

  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data } = await axios.get<Docu[]>(`${process.env.NEXT_PUBLIC_PERSONAL_SCHEDULE}`);
      setData(data);
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <>
      <SidebarAddHorario open={addHorarioOpen} toggle={toggleAddHorario} />
      <TableContainer component={Paper}>
        <Table aria-label="collapsible table">
          <TableHead>
            <TableRow
              sx={{
                '&:nth-of-type(odd)': {
                  backgroundColor: open ? theme.palette.mode === 'dark' ? '#263238' : '#263238' : theme.palette.mode === 'dark' ? '#263238' : '#263238',
                  boxShadow: 'inset 0px 0px 5px rgba(0, 0, 0, 0.5)',
                  color: '#ffffff',
                },
                '& > *': {
                  borderBottom: '1px solid #ccc',
                  color: '#ffffff',
                }
              }}>
              <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 10px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                N°
              </TableCell>
              <TableCell className={classes.tableCell} align="center" style={{ fontWeight: 'bold', padding: '3px 50px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                NOMBRE HORARIO
              </TableCell>
              <TableCell align="center" style={{ fontWeight: 'bold', padding: '3px 50px', borderRight: '1px solid rgba(224, 224, 224, 1)', borderBottom: '1px solid rgba(224, 224, 224, 1)', color: '#ffffff' }}>
                vista de horario
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((row) => (
              <Row key={row._id} row={row} />
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
}
function setData(updatedData: any) {
  throw new Error('Function not implemented.');
}

