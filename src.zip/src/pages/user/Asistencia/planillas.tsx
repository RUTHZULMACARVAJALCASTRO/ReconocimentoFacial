import { useState, useEffect } from 'react';
import Card from '@mui/material/Card';
import { DataGrid } from '@mui/x-data-grid';
import axios from 'axios';
import Button from '@mui/material/Button';
import SaveIcon from '@mui/icons-material/Save';
import { Typography } from '@mui/material';
import Link from 'next/link'
import { GridRenderCellParams } from '@mui/x-data-grid';

interface EntranceExit {
    hour: string;
    tolerance: number;
    marketHour: string;
    infraccion: string;
    type: string;
    status: string;
    shift: string
}

interface AttendanceDetail {
    date: string;
    specialDay?: string;
    entrances: EntranceExit[];
    exits: EntranceExit[];
}

interface PersonalData {
    id: string;
    personalId: string;
    name: string;
    lastName: string;
    ci: string;
    schedule: string;
    attendanceDetail: AttendanceDetail[];
}

const Planillas = () => {
    const [data, setData] = useState<PersonalData[]>([]);
    const [pageSize, setPageSize] = useState<number>(10);

    useEffect(() => {
        fetchData();
    }, []);

    const procesarDatos = (data: PersonalData[]) => {
        const processedData: any = {};
        console.log(data)
        data.forEach(personal => {
            console.log(personal.personalId)
            const latestAttendanceDetail = personal.attendanceDetail[personal.attendanceDetail.length - 1];
            const latestEntrance = latestAttendanceDetail.entrances[0];
            const latestExit = latestAttendanceDetail.exits[0];
            processedData[personal.personalId] = {
                id: personal.personalId,
                nombre: personal.name,
                apellido: personal.lastName,
                ci: personal.ci,
                horario: personal.schedule,
                tipo: latestEntrance ? 'ENTRADA' : 'SALIDA',
                estado: latestEntrance ? latestEntrance.status : latestExit.status,
                fecha: latestAttendanceDetail.date,
                horaDeRegistro: latestEntrance ? latestEntrance.marketHour : latestExit.marketHour,
            };
            console.log(processedData)
            console.log(latestEntrance, latestExit);
        });
        return Object.values(processedData);
    };


    const fetchData = async () => {
        try {
            const response = await axios.get(`http://10.10.214.132:3000/api/attendance`);
            const processedData = procesarDatos(response.data) as PersonalData[];
            setData(processedData);
        } catch (error) {
            console.log(error);
        }
    };


    const columns = [
        // { field: 'id', headerName: 'id', minWidth: 110 },
        { field: 'nombre', headerName: 'Nombre', minWidth: 110 },
        { field: 'apellido', headerName: 'Apellido', minWidth: 110 },
        { field: 'ci', headerName: 'C.I.', minWidth: 110 },
        { field: 'horario', headerName: 'Horario', minWidth: 110 },
        { field: 'tipo', headerName: 'Tipo', minWidth: 110 },
        { field: 'estado', headerName: 'Estado', minWidth: 110 },
        { field: 'fecha', headerName: 'Fecha de Asistencia', minWidth: 110 },
        { field: 'horaDeRegistro', headerName: 'Hora de Registro', minWidth: 110 },
        {
            flex: 0.1,
            minWidth: 110,
            field: 'view',
            headerName: 'Vista',
            renderCell: (params: { row: { id: any; }; }) => (
                <Link
                    href={`/user/usuario/view/${params.row.id}/`}
                    passHref
                >
                    <button >
                        Ver
                    </button>
                </Link>
            )
        }

    ];

    return (
        <>
            <Typography
                variant="h4"
                component="h1"
                align="center"
                style={{ margin: '20px 0', fontWeight: 'bold' }}
            >
                PLANILLA DE ASISTENCIA
            </Typography>
            <Button
                variant="contained"
                color="primary"
                startIcon={<SaveIcon />}
                style={{ marginBottom: '16px' }}
            >
                Exportar a PDF
            </Button>
            <Card>
                <DataGrid
                    getRowId={(row) => row.id}
                    autoHeight
                    rows={data}
                    columns={columns}
                    pageSize={pageSize}
                    disableSelectionOnClick
                    rowsPerPageOptions={[10, 25, 50]}
                    onPageSizeChange={(newPageSize: number) => setPageSize(newPageSize)}
                    localeText={{
                        // Cambia los textos de ordenamiento
                        // Puedes modificar estas cadenas según tus necesidades
                        toolbarDensity: 'Densidad',
                        toolbarDensityLabel: 'Densidad',
                        toolbarDensityCompact: 'Compacta',
                        toolbarDensityStandard: 'Estándar',
                        toolbarDensityComfortable: 'Cómoda',
                        // sortAscending: 'Ordenar ascendente',
                        // sortDescending: 'Ordenar descendente',
                        columnMenuShowColumns: 'Mostrar columnas',
                        columnMenuFilter: 'Filtrar',
                        columnMenuHideColumn: 'Ocultar columna',
                        columnMenuUnsort: 'Quitar orden',
                        columnMenuSortAsc: 'Ordenar ascendente',
                        columnMenuSortDesc: 'Ordenar descendente'
                    }}
                />
            </Card>
        </>
    );
};

export default Planillas;



// const exportToPDF = async () => {
//     const domElement = document.getElementById('dataGridContainer');
//     if (!domElement) return;

//     const pdf = new jsPDF('p', 'mm', 'a4');  // a4 size paper.
//     const width = pdf.internal.pageSize.getWidth();
//     const height = pdf.internal.pageSize.getHeight();

//     // Aumentamos la calidad del canvas al escalarlo
//     const canvas = await html2canvas(domElement, {
//         scale: 5 // puedes ajustar este valor según tus necesidades
//     });

//     const imgData = canvas.toDataURL('image/png');

//     const imgProps = pdf.getImageProperties(imgData);
//     const pdfWidth = width;
//     const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

//     // Ajustamos la imagen al centro y mantenemos las proporciones
//     const marginLeft = 0; // podrías ajustar este para centrar si lo necesitas
//     const marginTop = (height - pdfHeight) / 2;

//     pdf.addImage(imgData, 'PNG', marginLeft, marginTop, pdfWidth, pdfHeight);
//     pdf.save('planilla_asistencia.pdf');
// };


// const exportToExcel = () => {
//     const ws = XLSX.utils.json_to_sheet(data);
//     const wb = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(wb, ws, "PlanillaAsistencia");
//     XLSX.writeFile(wb, "planilla_asistencia.xlsx");
// };