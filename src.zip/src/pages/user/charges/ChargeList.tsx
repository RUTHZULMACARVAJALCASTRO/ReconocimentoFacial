// import Card from '@mui/material/Card'
// import Grid from '@mui/material/Grid'
// import { DataGrid } from '@mui/x-data-grid'
// import CustomChip from 'src/@core/components/mui/chip'
// import axios from 'axios'
// import TableHeader from 'src/views/apps/user/list/TableHeaderCharge'
// import { Avatar, Box, Button, ButtonGroup, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, IconButton, List, ListItem, ListItemAvatar, ListItemButton, ListItemText, Menu, MenuItem, TableBody, TableCell, TableRow, TextField, Tooltip, Typography } from '@mui/material'
// import Icon from 'src/@core/components/icon';
// import { LayoutProps, ThemeColor } from '../../../@core/layouts/types';
// import SidebarAddCharge from 'src/views/apps/user/list/AddCharge';
// import React from 'react';  // Ensure React is imported
// import SidebarEditCharge from './EditCharge'
// import { useState, useEffect, MouseEvent, useCallback } from 'react'
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import Menu from '@mui/material/Menu'
import Grid from '@mui/material/Grid'

import { DataGrid } from '@mui/x-data-grid'
import { styled } from '@mui/material/styles'
import MenuItem from '@mui/material/MenuItem'
import IconButton from '@mui/material/IconButton'
import Typography from '@mui/material/Typography'
import Icon from 'src/@core/components/icon';
import { useState, useEffect, MouseEvent, useCallback } from 'react'
import Link from 'next/link'
import charge, { fetchCharges } from 'src/store/apps/charge/index';
import { useDispatch, useSelector } from 'react-redux'
import { toggleChargeStatus } from 'src/store/apps/charge/index';
import { RootState } from 'src/store';
import { AppDispatch } from 'src/redux/store';
import CustomChip from 'src/@core/components/mui/chip'
import CustomAvatar from 'src/@core/components/mui/avatar'
import { getInitials } from 'src/@core/utils/get-initials'
import { ThemeColor } from 'src/@core/layouts/types'

import TableHeader from 'src/views/apps/user/list/TableHeaderCharge'
import { rows } from 'src/@fake-db/table/static-data';
import axios from 'axios';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Button from '@mui/material/Button';
import SidebarAddCharge from 'src/views/apps/charge/AddCharge'
import SidebarEditCharge from 'src/views/apps/charge/EditCharge'
import Tooltip from '@mui/material/Tooltip';
interface HTMLElement extends Element { }

export interface Docu {
  _id: string
  name: string
  description: string
  isActive: boolean
}

interface ChargeData {
  _id: string
  name: string
  description: string
  isActive: boolean
}

interface CellType {
  row: Docu
}

interface ChargeStatusType {
  [key: string]: ThemeColor
}

const ChargeList = () => {
  // ** State
  const [data, setData] = useState<Docu[]>([])
  const [value, setValue] = useState<string>('')
  const [pageSize, setPageSize] = useState<number>(10)
  const [addChargeOpen, setAddChargeOpen] = useState<boolean>(false)
  const [editChargeOpen, setEditChargeOpen] = useState<boolean>(false)
  const [selectedChargeId, setSelectedChargeId] = useState<string | null>(null);
  const toggleAddCharge = () => setAddChargeOpen(!addChargeOpen)

  const dispatch = useDispatch<AppDispatch>()

  const charges: Docu[] = useSelector((state: RootState) => state.charges.list);

  useEffect(() => {
    dispatch(fetchCharges());
  }, [dispatch]);


  const toggleChargeActivation = async (chargeId: string, isActive: boolean) => {
    console.log(`Setting charge with ID ${chargeId} active status to: ${isActive}`);

    try {
      await dispatch(toggleChargeStatus({ chargeId, isActive })).unwrap();

    } catch (error) {
      console.error("Error making the PUT request to update status:", error);
    }
  };

  const chargeStatusObj: ChargeStatusType = {
    activo: 'success',
    inactivo: 'secondary'
  }

  const RowOptions = ({ id, isActive }: { id: number | string, isActive: boolean }) => {

    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
    const [openDialog, setOpenDialog] = useState(false);
    const rowOptionsOpen = Boolean(anchorEl)


    const handleOpenDialog = () => {
      setOpenDialog(true);
    };

    const handleCloseDialog = () => {
      setOpenDialog(false);
    };

    const handleDeactivate = () => {
      toggleChargeActivation(id.toString(), false);
      setOpenDialog(false);
    };

    const handleReactivate = () => {
      toggleChargeActivation(id.toString(), true);
    };

    const handleRowOptionsClick = (event: MouseEvent<HTMLElement>) => {
      console.log('click aqui')
      setAnchorEl(event.currentTarget)
    }
    const handleRowOptionsClose = () => {
      setAnchorEl(null)
    }


    const handleUpdate = (chargeId: string) => () => {
      setSelectedChargeId(chargeId);
      setEditChargeOpen(true);
      console.log("handleUpdate called:", chargeId, editChargeOpen);
    };

    return (
      <>
        <IconButton size='small' onClick={handleRowOptionsClick}>
          <Icon icon='mdi:dots-vertical' />
        </IconButton>
        <Menu
          keepMounted
          anchorEl={anchorEl}
          open={rowOptionsOpen}
          onClose={handleRowOptionsClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'right'
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right'
          }}
          PaperProps={{ style: { minWidth: '8rem' } }}
        >


          <Tooltip
            title={isActive ? '' : 'No se puede editar este cargo porque no está activo'}
            arrow
            placement="top"
          >
            <span>
              <MenuItem
                onClick={isActive ? handleUpdate(id.toString()) : undefined}
                sx={{
                  '& svg': { mr: 2 },
                  pointerEvents: isActive ? 'auto' : 'none', // Deshabilita el clic si el usuario está inactivo.
                  opacity: isActive ? 1 : 0.5, // Cambia la opacidad si el usuario está inactivo.
                }}
              >
                <Icon icon='mdi:edit' fontSize={20} />
                Editar
              </MenuItem>
            </span>
          </Tooltip>
          <MenuItem onClick={isActive ? handleOpenDialog : handleReactivate} sx={{ '& svg': { mr: 2 } }}>
            <Icon icon={isActive ? 'mdi:delete-outline' : 'mdi:account-check-outline'} fontSize={20} />
            {isActive ? 'Dar de Baja' : 'Activar'}
          </MenuItem>
        </Menu>

        <Dialog open={openDialog} onClose={handleCloseDialog}>
          <DialogTitle>¿Estás seguro?</DialogTitle>
          <DialogContent>
            <DialogContentText>¿Realmente quieres desactivar este usuario?</DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog} color="primary">
              Cancelar
            </Button>
            <Button onClick={handleDeactivate} color="primary">
              Desactivar
            </Button>
          </DialogActions>
        </Dialog>
      </>
    )
  }

  const handleFilter = useCallback((val: string) => {
    setValue(val)
  }, [])
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const columns = [

    {
      flex: 0.1,
      minWidth: 150,
      field: 'name',
      headerName: 'Nombre',
      renderCell: ({ row }: CellType) => {
        return (
          <Typography noWrap variant='body2'>
            {row.name}
          </Typography>
        )
      }
    },
    {
      flex: 0.1,
      minWidth: 110,
      field: 'description',
      headerName: 'Descripcion',
      renderCell: ({ row }: CellType) => {
        return (
          <Typography noWrap variant='body2'>
            {row.description}
          </Typography>
        )
      }
    },
    {
      flex: 0.1,
      minWidth: 110,
      field: 'status',
      headerName: 'Estado',
      renderCell: ({ row }: CellType) => {
        const status = row.isActive ? 'activo' : 'inactivo';
        return (
          <CustomChip
            skin='light'
            size='small'
            label={status}
            color={chargeStatusObj[status]}
            sx={{ textTransform: 'capitalize', '& .MuiChip-label': { lineHeight: '18px' } }}
          />
        )
      }
    },
    {
      flex: 0.1,
      minWidth: 90,
      sortable: false,
      field: 'actions',
      headerName: 'Acciones',
      renderCell: ({ row }: CellType) => <RowOptions id={row._id} isActive={row.isActive} />
    }
  ]
  return (
    <>
      <Grid container spacing={50}>
        <Grid item xs={12}>
          <Card>
            <TableHeader value={value} handleFilter={handleFilter} toggle={toggleAddCharge} />
            <DataGrid
              getRowId={row => row._id}
              autoHeight
              rows={charges}
              columns={columns}
              pageSize={pageSize}
              disableSelectionOnClick
              sx={{ '& .MuiDataGrid-columnHeaders': { borderRadius: 0 } }}
              onPageSizeChange={(newPageSize: number) => setPageSize(newPageSize)}
              localeText={{
                filterOperatorAfter: 'después de',
                filterOperatorOnOrAfter: 'en o después de',
                filterOperatorBefore: 'antes de',
                filterOperatorOnOrBefore: 'en o antes de',
                filterOperatorEquals: 'igual a',
                filterOperatorStartsWith: 'comienza con',
                filterOperatorEndsWith: 'termina con',
                filterOperatorContains: 'contiene',
                columnMenuLabel: 'Menú de columna',
                columnMenuShowColumns: 'Mostrar columnas',
                columnMenuFilter: 'Filtrar',
                columnMenuHideColumn: 'Ocultar',
                columnMenuUnsort: 'Desordenar',
                columnMenuSortAsc: 'Ordenar Asc',
                columnMenuSortDesc: 'Ordenar Desc',
                toolbarDensity: 'Densidad',
                toolbarDensityLabel: 'Densidad',
                toolbarDensityCompact: 'Compacto',
                toolbarDensityStandard: 'Estándar',
                toolbarDensityComfortable: 'Cómodo',
                noRowsLabel: 'No hay filas',
                noResultsOverlayLabel: 'No se encontraron resultados.',
                errorOverlayDefaultLabel: 'Ocurrió un error.'
              }}

            />
          </Card>
        </Grid>

        <SidebarAddCharge open={addChargeOpen} toggle={toggleAddCharge} />
        {selectedChargeId && <SidebarEditCharge chargeId={selectedChargeId} open={editChargeOpen} toggle={() => setEditChargeOpen(false)} />}
      </Grid>
    </>
  )
}


export default ChargeList