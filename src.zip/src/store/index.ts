// ** Toolkit imports
import { combineReducers } from '@reduxjs/toolkit'
import userReducer from './apps/user';
import chargeReducer from './apps/charge'
// ** Reducers

// import invoice from 'src/store/apps/invoice'

// import permissions from 'src/store/apps/permissions'

export const rootReducer = combineReducers({
  users: userReducer,
  charges: chargeReducer,
})

export type RootState = ReturnType<typeof rootReducer>;