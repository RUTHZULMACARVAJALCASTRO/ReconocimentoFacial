import { createSlice, PayloadAction, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { ThemeColor } from 'src/@core/layouts/types';
import { Docu } from 'src/pages/user/usuario/userlist';

export interface UserData {
  name: string;
  lastName: string;
  ci: string;
  email: string;
  phone: string;
  address: string;
  nationality: string;
  unity: string;
  charge: string;
  schedule: string;
  file: any;
  _id: string;
  isActive: boolean;
}

interface UserState {
  data: UserData | null;
  list: UserData[];
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const initialState: UserState = {
  data: null,
  list: [],
  status: 'idle',
  error: null
};

type PartialUserData = Partial<UserData>;

// Thunk para agregar usuario
export const addUser = createAsyncThunk(
  'users/addUser',
  async (userData: UserData) => {
    const response = await axios.post(`${process.env.NEXT_PUBLIC_PERSONAL}`, userData);
    return response.data;
  }
);

export const fetchUsers = createAsyncThunk(
  'users/fetchUsers',
  async (): Promise<UserData[]> => {
    const response = await axios.get(`${process.env.NEXT_PUBLIC_PERSONAL}`);
    return response.data;
  }
);

export const editUser = createAsyncThunk(
  'users/editUser',
  async (updatedUser: PartialUserData): Promise<UserData> => {
    if (!updatedUser._id) {
      throw new Error('Se requiere el ID del usuario para actualizar');
    }
    const response = await axios.put(`${process.env.NEXT_PUBLIC_PERSONAL}edit/${updatedUser._id}`, updatedUser);

    if (!response.data || response.status !== 200) {
      throw new Error('Error al actualizar el personal');
    }

    return response.data;
  }
);
export const toggleUserStatus = createAsyncThunk(
  'users/toggleActivation',
  async ({ userId, isActive }: { userId: string; isActive: boolean }): Promise<Docu> => {
      const response = await axios.put(`${process.env.NEXT_PUBLIC_PERSONAL}edit/${userId}`, { isActive: isActive });

      if (!response.data || response.status !== 200) {
          throw new Error('Error al cambiar el estado de activación del persoanl');
      }

      return response.data;
  }
);

const userSlice = createSlice({
  name: 'users',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addUser.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(addUser.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.list.push(action.payload);
        state.data = action.payload;
      })
      .addCase(addUser.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || null;
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.list = action.payload;
      })

      .addCase(editUser.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(editUser.fulfilled, (state, action: PayloadAction<UserData>) => {
        state.status = 'succeeded';
        const index = state.list.findIndex(user => user._id === action.payload._id);
        if (index !== -1) {
          state.list[index] = action.payload;
        }
        state.data = action.payload;
      })
      .addCase(editUser.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || null;
      })
      .addCase(toggleUserStatus.pending, (state) => {
        state.status = 'loading';
    })
    .addCase(toggleUserStatus.fulfilled, (state, action: PayloadAction<Docu>) => {
        state.status = 'succeeded';
        const index = state.list.findIndex(user => user._id === action.payload._id);
        if (index !== -1) {
            state.list[index] = action.payload;  // Asumiendo que la respuesta del servidor contiene el cargo actualizado
        }
    })
    .addCase(toggleUserStatus.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || null;
    });
  }
});

export default userSlice.reducer;