import { createSlice, PayloadAction, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { ThemeColor } from 'src/@core/layouts/types';
import { Docu } from 'src/pages/user/charges/ChargeList';

export interface Schedule {
    day: number;
    into: string;
    out: string;
    intoTwo: string;
    outTwo: string;
    toleranceInto: number;
    toleranceOut: number;
}

export interface ScheduleSpecial {
    name: string;
    day: number;
    into: string;
    out: string;
    intoTwo: string;
    outTwo: string;
    toleranceInto: number;
    toleranceOut: number;
    permanente: boolean;
    dateRange: string[];
    usersAssigned: string[];
}

export interface ScheduleData {
    name: string;
    scheduleNormal: Schedule[];
    scheduleSpecial: ScheduleSpecial[];
}
interface ScheduleState {
    data: ScheduleData | null;
    list: Docu[];
    status: 'idle' | 'loading' | 'succeeded' | 'failed';
    error: string | null;
}

const initialState: ScheduleState = {
    data: null,
    list: [],
    status: 'idle',
    error: null
};

// Thunk para agregar usuario
export const addHorario = createAsyncThunk(
    'schedules/addSchedule',
    async (schedule) => {
        const response = await axios.post(`${process.env.NEXT_PUBLIC_PERSONAL_SCHEDULE}`, schedule);
        return response.data;
    }
);


export const fetchSchedule = createAsyncThunk(
    'charges/fetchCharges',
    async (): Promise<Docu[]> => {
        const response = await axios.get(`${process.env.NEXT_PUBLIC_PERSONAL_SCHEDULE}`);
        return response.data;
    }
);

const scheduleSlice = createSlice({
    name: 'charges',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(addHorario.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(addHorario.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.list.push(action.payload);
                state.data = action.payload;
            })
            .addCase(addHorario.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message || null;
            })
            .addCase(fetchSchedules.fulfilled, (state, action) => {
                state.list = action.payload;
            })


    }
});

export default scheduleSlice.reducer;