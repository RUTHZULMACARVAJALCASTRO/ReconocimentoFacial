
import { configureStore } from '@reduxjs/toolkit'
import counterReducer from '../redux/slices/counterSlice'
import userReducer from '../store/apps/user'
import chargeReducer from '../store/apps/charge'

export const store = configureStore({
  reducer: {
    counter: counterReducer,
    users: userReducer,
    charges: chargeReducer,
  }
})

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch